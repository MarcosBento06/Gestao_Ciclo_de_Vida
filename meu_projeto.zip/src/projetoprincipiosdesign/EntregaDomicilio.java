package projetoprincipiosdesign;

public class EntregaDomicilio implements TipoEntrega{

    @Override
    public double calcularFrete(double total) {
        return 15.0;
    }
}
