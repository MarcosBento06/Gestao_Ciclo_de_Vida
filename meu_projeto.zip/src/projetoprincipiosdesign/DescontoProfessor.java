package projetoprincipiosdesign;

public class DescontoProfessor implements Desconto{

    @Override
    public double aplicar(double total){
        return total *= 0.85;
    }
}
