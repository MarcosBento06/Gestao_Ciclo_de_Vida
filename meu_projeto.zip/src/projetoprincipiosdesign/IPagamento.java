package projetoprincipiosdesign;

public interface IPagamento {
    void pagar(double valor);

    void gerarPedido(double valor);
}
