package projetoprincipiosdesign;

public class DescontoAluno implements Desconto{

    @Override
    public double aplicar(double total){
        return total *= 0.90;
    }
}
