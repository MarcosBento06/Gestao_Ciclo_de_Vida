package projetoprincipiosdesign;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class PedidoService {

    PagamentoCartao pagamentoCartao = new PagamentoCartao();

    public double calcularTotal(Pedido pedido, Desconto desconto) {
        double total = 0.0;

        for (ItemPedido item : pedido.getItens()) {
            total += item.getPreco() * item.getQuantidade();
        }

        return desconto.aplicar(total);
    }

    public String obterCidadeEntrega(Pedido pedido) {
        return pedido.getCidadeEntrega();
        //pedido.getCliente().getEndereco().getCidade().getNome();
    }

    public void finalizarPedido(Pedido pedido, IPagamento pagamento, Desconto desconto) {
        double total = calcularTotal(pedido, desconto);

        PedidoRepository repository = new PedidoRepository();
        repository.salvamentoPedido(pedido, total);

        pagamento.gerarPedido(total);

        System.out.println(
            "Enviando mensagem para " + pedido.getCliente().getNome() + ": pedido finalizado."
        );
    }
}
