package projetoprincipiosdesign;

public class DescontoFuncionario implements Desconto{

    @Override
    public double aplicar(double total){
        return total *= 0.80;
    }
}
