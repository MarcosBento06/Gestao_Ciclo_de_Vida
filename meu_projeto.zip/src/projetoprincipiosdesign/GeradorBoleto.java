package projetoprincipiosdesign;

public interface GeradorBoleto {
    void gerarBoleto(double valor);
}
