package projetoprincipiosdesign;

public class PagamentoBoleto implements IPagamento, GeradorBoleto {
    @Override
    public void pagar(double valor) {
        System.out.printf("Boleto registrado: R$ %.2f%n", valor);
    }

    @Override
    public void gerarBoleto(double valor) {
        System.out.printf("Linha digitável gerada para R$ %.2f%n", valor);
    }

    @Override
    public void gerarPedido(double valor){
        System.out.println("Processando pagamento via Boleto no valor de R$ " + valor);
    }
}
