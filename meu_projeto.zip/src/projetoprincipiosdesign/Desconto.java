package projetoprincipiosdesign;

public interface Desconto {
    double aplicar(double total);
}
