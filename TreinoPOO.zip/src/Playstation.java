public class Playstation implements IConsole{

    protected DadosConsole console;

    public Playstation(String nome, double precoBase){
        this.console = new DadosConsole(nome, precoBase);
    }

    @Override
    public String getNome(){
        return console.getNome();
    }

    @Override
    public void ligar(){
        System.out.println("Playstation ligado.");
    }

    @Override
    public double calcularPreco(){
        return console.getPrecoBase() * 1.20;
    }




}
