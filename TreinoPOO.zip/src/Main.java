import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        Loja loja = new Loja();
        List<IConsole> consoles = new ArrayList<>();

        consoles.add(new Nintendo("Nintendo", 2000));
        consoles.add(new Playstation("Playstation 5", 3000));
        consoles.add(new PlaystationPortatil("Playstation Portátil", 2500));

        System.out.println("Vendendo vários consoles\n");
        loja.venderVarios(consoles);
        double faturamento = loja.calcularFaturamentoTotal(consoles);

        System.out.println("\nFaturamento total das vendas: " + faturamento);

        consoles.add(new Xbox("X Box Series S", 3000));

        System.out.println("\nVendendo mais um console\n");
        loja.venderVarios(consoles);
        faturamento = loja.calcularFaturamentoTotal(consoles);

        System.out.println("Faturamento total das vendas: " + faturamento);








    }
}
