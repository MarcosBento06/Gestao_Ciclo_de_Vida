public class Nintendo implements IConsole{

    DadosConsole console;

    public Nintendo(String nome, double precoBase){
        this.console = new DadosConsole(nome, precoBase);
    }

    @Override
    public String getNome(){
        return console.getNome();
    }

    @Override
    public void ligar(){
        System.out.println("Nintendo ligado.");
    }

    public double calcularPreco(){
        return console.getPrecoBase() * 1.10;
    }
}
