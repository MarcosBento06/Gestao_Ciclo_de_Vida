import java.util.List;

public class Loja {

    public void venderVarios(List<IConsole> consoles){

        for(int i = 0; i < consoles.size(); i++){
            IConsole console = consoles.get(i);
            venderConsole(console);
        }
    }

    public double calcularFaturamentoTotal(List<IConsole> consoles){
        double somaTotal = 0.0;
        for(int i = 0; i < consoles.size(); i++){
            somaTotal += consoles.get(i).calcularPreco();
        }
        return somaTotal;
    }

    public void venderConsole(IConsole console) {
       console.ligar();
       console.calcularPreco();
    }
}
