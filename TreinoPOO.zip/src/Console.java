public class Console {

    private String nome;
    private String tipo;   // "nintendo", "playstation" ou "portatil"
    private double preco;

    public Console(String nome, String tipo, Double preco){
        this.nome = nome;
        this.tipo = tipo;
        this.preco = preco;
    }

    public String getNome(){
        return this.nome;
    }

    public String getTipo(){
        return this.tipo;
    }

    public Double getPreco(){
        return this.preco;
    }

}
