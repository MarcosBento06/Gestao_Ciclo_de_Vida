public class DadosConsole {
    private double precoBase;
    private String nome;

    public DadosConsole(String nome, double precoBase) {
        this.nome = nome;
        this.precoBase = precoBase;
    }

    public double getPrecoBase(){
        return this.precoBase;
    }

    public String getNome(){
        return this.nome;
    }


}
