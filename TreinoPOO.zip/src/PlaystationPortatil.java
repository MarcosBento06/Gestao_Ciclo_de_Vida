public class PlaystationPortatil extends Playstation{

    public PlaystationPortatil(String nome, double precoBase){
        super(nome, precoBase);
        this.console = new DadosConsole(nome, precoBase);
    }

    @Override
    public void ligar(){
        System.out.println("Playstation Portátil ligado.");
    }

    @Override
    public double calcularPreco(){
        return console.getPrecoBase() * 1.15;
    }
}
