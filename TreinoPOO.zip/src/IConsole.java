public interface IConsole {

     String getNome();
     void ligar();
     double calcularPreco();


}
